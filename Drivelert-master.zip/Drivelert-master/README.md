# Drivelert
Playstore link - https://play.google.com/store/apps/details?id=com.drivelert.akarshan.drivelert
Drivelert is an android application that helps to combat a dangerous and unrecognised social issue known as drowsy driving. 
It tracks drivers eyes and initiates alert when driver tends to sleep while driving.
It is made using Google Mobile Vision Library.

The face is detected by the app.
<br>
![alt tag](https://github.com/akarshan96/Drivelert/blob/master/main-qimg-407edd0ab59bb2e648a3ce94cdf5452c.png)
<br>
And if the eyes remains closed for a time period, Alarm invokes
<br>
![alt tag](https://github.com/akarshan96/Drivelert/blob/master/main-qimg-17bd210133da2039886d57c07fee7c88.png)
<br>
The time can be customized by the user before the monitoring process!

